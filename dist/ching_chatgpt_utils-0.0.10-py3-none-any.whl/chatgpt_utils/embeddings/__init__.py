from .utils import dot, cosine
from .embeddings import get_hf_embeddings, get_openai_embeddings
